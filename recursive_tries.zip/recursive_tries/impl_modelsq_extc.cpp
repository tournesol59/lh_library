#include "decl_modelsq_extc.h"

IDENT05_MODELSQ_EXTC::IDENT05_MODELSQ_EXTC(vectorop yvalues, int dsize, int dn) : IDENT05_MODELSQ(yvalues, dsize, dn)
{
   // nothing besides base data
}

IDENT05_MODELSQ_EXTC::IDENT05_MODELSQ_EXTC(const IDENT05_MODELSQ_EXT ccp) : IDENT05_MODELSQ(ccp)
{
   // nothing besides base data
}

IDENT05_MODELSQ_EXTC &IDENT05_MODELSQ_EXTC::operator=(const IDENT05_MODELSQ_EXTC ccp)// : IDENT05_MODELSQ(ccp)
{
   // nothing besides base data
}

IDENT05_MODELSQ_EXTC::~IDENT05_MODELSQ_EXTC()
{
}

void IDENT05_MODELSQ_EXTC::setphivalues(int ind) {
   int i;
   for (i=0; i<n; i++) {
      phi.values[i]=y.values[ind-i];
   }
}

void IDENT05_MODELSQ_EXTC::predict(int ind, double &epsilon) {
   double res;
   multiply_scalprod(coeffs, vec, res, n);
   epsilon = y.values[ind]-res;
}

void IDENT05_MODELSQ_EXTC::innovation(int ind, double epsilon) {
   int i;
   vectorop tempA(n);
   vectorop tempB(n);
   multiply_scalvec(epsilon, matrixK, tempA, n);
   addvec(coeffs, tempA, tempB);
   coeffs=tempB; // test this
}

void IDENT05_MODELSQ_EXTC::update(int ind) {
   int i,j;
   double den;
   vectorop Fphi;
   multiply_matrix_vec(matrixF, phi, vectorop Fphi, n);
   multiply_scalprod(phi, Fphi, den, n);
   den=1.0+den;
}


/*----------- C-style submethods but with overloaded operator  -----------*/

void add_vec(vectorop &veca, vectorop &vecb, vectorop &res, int n) {
  int i;
  for (i=0; i<n; i++) {
	  res.values[i]=veca.values[i]+vecb.values[i];
  }
  return 0;
}

void multiply_scalvec(double scal, vectorop vec, vectorop res, int n) {
  int i;
  for (i=0; i<n; i++) {
	  res.values[i]=scal*vec.values[i];
  }
  return 0;
}

void multiply_scalprod(vectorop &row, vectorop &vec, double &res, int n) {
  int i;
  res=0.0;
  for (i=0; i<n; i++) {
	  res=res+row.values[i]*vec.values[i];
  }
  return 0;
}

// a trick is used here: matrix mat is implemented as a vector (row_major)
void multiply_matrix_vec(vectorop &mat, vectorop vec, vectorop res, int n) {
  int i,j;
  double sum;
  for (i=0; i<n; i++) {
     sum=0.0;
     for (j=0; j<n; j++) {
         sum=sum+mat.values[n*i+j]*vec.values[j];
     }
     res.values[i]=sum;
  }
  return 0;
}

bool IDENT05_MODELSQ_EXTC::pass_iodata(std::vector<std::pair<double,double>> &list_yh, std::string str_data)
{
  int k, sel=1;
  std::pair<double,double> singleton;

  if (!(str_data.compare("yori"))) {
	  std::cout << "match yori\n";
	  sel=1;
  }
  else if (!(str_data.compare("uori"))) {
	  sel=2;
  }
  else if (!(str_data.compare("yst0"))) {
	  sel=3;
  }
  for (k=0; k<size; k++) {
      singleton.first = (double (k))*Ts;
      switch (sel) {
         case 1:  singleton.second = y[k];
		  break;
	 case 2:  singleton.second = u[k];
		  break;
         case 3:  singleton.second = y_h[k];
		  break;
      }
      std::cout << singleton.second << " ";
      list_yh.push_back( singleton );
  }

  return 1;
}



